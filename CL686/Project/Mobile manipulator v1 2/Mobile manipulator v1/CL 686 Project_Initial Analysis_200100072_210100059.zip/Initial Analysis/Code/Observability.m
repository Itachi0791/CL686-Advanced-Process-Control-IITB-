%% Observability Matrix

syms q1 q2 x0 y0 q1_d q2_d x0_d y0_d
syms l1 l2 

x_vec = [q1;q2;x0;y0;q1_d;q2_d;x0_d;y0_d];
Y = [x0 + l1 * cos(q1) + l2 * cos(q1 + q2); y0 + l1 * sin(q1) + l2 * sin(q1 + q2)];

C_mat = jacobian(Y,x_vec);

matlabFunction(C_mat,"File","C_matrix","Vars",{l1,l2,x_vec})



