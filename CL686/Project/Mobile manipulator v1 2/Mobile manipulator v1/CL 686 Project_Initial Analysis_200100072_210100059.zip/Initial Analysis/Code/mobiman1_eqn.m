%% Deriving the equations of motion of a Mobile Manipulator using Symbolic  Math Toolbox

% In this code, the equations governing the dynamics of the Mobile Manipulator are
% derived using the Symbolic Math Toolbox

% Link 1 = Mobile Base
% Link 2 = Manipulator Link

%% Create symbols

syms m1 l1 lc1 m2 l2 lc2 g  % Mass and Length parameters
syms posx(t) posy(t) posx_d(t) posy_d(t) theta1(t) theta1_d(t) theta2(t) theta2_d(t) % Placeholder state variables
syms t % Time
syms px px_d px_dd py py_d py_dd q1 q1_d q1_dd q2 q2_d q2_dd % State variables and their derivatives as a function of time
syms Fx Fy tau1 tau2 % Force and Torque actuator inputs
syms d1 d2 d3 d4 % Disturbance Inputs

%% Create variables

I1 = (m1 * l1^2)/12; % Inertia of link 1 about COM
I2 = (m2 * l2^2)/12; % Inertia of link 2 about COM
w1 = theta1_d(t); % Angular velocity of link 1
w2 = theta1_d(t) + theta2_d(t); % Angular velocity of link 2

pos2x_d = posx_d(t) - l1 * w1 * sin(theta1(t)); % x-component of velocity of the joint between link 1 and link 2
pos2y_d = posy_d(t) + l1 * w1 * cos(theta1(t)); % y-component of velocity of the joint between link 1 and link 2

K1 = 0.5 * I1 * w1.^2 +  0.5 * m1 * ((lc1 * w1 * cos(theta1(t)) + posy_d(t))^2 + (-lc1 * w1 * sin(theta1(t)) + posx_d(t))^2); % KE of link 1
K2 = 0.5 * I2 * w2.^2 +  0.5 * m2 * ((lc2 * w2 * cos(theta1(t) + theta2(t)) + pos2y_d)^2 + (-lc2 * w2 * sin(theta1(t) + theta2(t)) + pos2x_d)^2); % KE of link 2
K = K1 + K2; % Total Kinetic energy

P = 0; % Total potential energy

L = K - P; % Lagrangian

%% Euler-Lagrange equation

%Fx = Ft * cos(theta1(t)); % x-component of thrust on the base
%Fy = Ft * sin(theta1(t)); % y-component of thrust on the base

Eqn1 = diff(diff(L,theta1_d(t)),t) - diff(L,theta1(t)) - tau1 - d1 == 0; % For link 1
Eqn2 = diff(diff(L,theta2_d(t)),t) - diff(L,theta2(t)) - tau2 - d2 == 0; % For link 2
Eqn3 = diff(diff(L,posx_d(t)),t) - diff(L,posx(t)) - Fx - d3 == 0; % For x-component of mobile base
Eqn4 = diff(diff(L,posy_d(t)),t) - diff(L,posy(t)) - Fy - d4 == 0; % For y-component of mobile base

% Substitute q1_dd, q2_dd, px_dd, py_dd into the equations
Eqn1 = subs(Eqn1, [diff(theta1_d(t),t),diff(theta2_d(t),t),diff(posx_d(t),t),diff(posy_d(t),t)], [q1_dd,q2_dd,px_dd,py_dd]);
Eqn2 = subs(Eqn2, [diff(theta1_d(t),t),diff(theta2_d(t),t),diff(posx_d(t),t),diff(posy_d(t),t)], [q1_dd,q2_dd,px_dd,py_dd]);
Eqn3 = subs(Eqn3, [diff(theta1_d(t),t),diff(theta2_d(t),t),diff(posx_d(t),t),diff(posy_d(t),t)], [q1_dd,q2_dd,px_dd,py_dd]);
Eqn4 = subs(Eqn4, [diff(theta1_d(t),t),diff(theta2_d(t),t),diff(posx_d(t),t),diff(posy_d(t),t)], [q1_dd,q2_dd,px_dd,py_dd]);

% Substitute q1_d, q2_d, px_d, py_d into the equations
Eqn1 = subs(Eqn1, [diff(theta1(t),t),diff(theta2(t),t),diff(posx(t),t),diff(posy(t),t)], [q1_d,q2_d,px_d,py_d]);
Eqn2 = subs(Eqn2, [diff(theta1(t),t),diff(theta2(t),t),diff(posx(t),t),diff(posy(t),t)], [q1_d,q2_d,px_d,py_d]);
Eqn3 = subs(Eqn3, [diff(theta1(t),t),diff(theta2(t),t),diff(posx(t),t),diff(posy(t),t)], [q1_d,q2_d,px_d,py_d]);
Eqn4 = subs(Eqn4, [diff(theta1(t),t),diff(theta2(t),t),diff(posx(t),t),diff(posy(t),t)], [q1_d,q2_d,px_d,py_d]);

Eqn1 = subs(Eqn1, [theta1_d(t),theta2_d(t),posx_d(t),posy_d(t)], [q1_d,q2_d,px_d,py_d]);
Eqn2 = subs(Eqn2, [theta1_d(t),theta2_d(t),posx_d(t),posy_d(t)], [q1_d,q2_d,px_d,py_d]);
Eqn3 = subs(Eqn3, [theta1_d(t),theta2_d(t),posx_d(t),posy_d(t)], [q1_d,q2_d,px_d,py_d]);
Eqn4 = subs(Eqn4, [theta1_d(t),theta2_d(t),posx_d(t),posy_d(t)], [q1_d,q2_d,px_d,py_d]);

% Substitute q1,q2,px,py into the equations
Eqn1 = subs(Eqn1,[theta1(t),theta2(t),posx(t),posy(t)],[q1,q2,px,py]); 
Eqn2 = subs(Eqn2,[theta1(t),theta2(t),posx(t),posy(t)],[q1,q2,px,py]);
Eqn3 = subs(Eqn3,[theta1(t),theta2(t),posx(t),posy(t)],[q1,q2,px,py]);
Eqn4 = subs(Eqn4,[theta1(t),theta2(t),posx(t),posy(t)],[q1,q2,px,py]);

% Solve for q1_ddot, q2_ddot, px_dd, py_dd
[q1_dd, q2_dd, px_dd, py_dd] = solve([Eqn1, Eqn2, Eqn3, Eqn4], [q1_dd, q2_dd, px_dd, py_dd]);

q1_dd = simplify(q1_dd);
q2_dd = simplify(q2_dd);
px_dd = simplify(px_dd);
py_dd = simplify(py_dd);

% Expression for Power due to the actuator inputs

Pow = tau1 * q1_d + tau2 * q2_d + Fx * px_d + Fy * py_d;

% Expression for Power due to the disturbance inputs
Pow_d = d1 * q1_d + d2 * q2_d + d3 * px_d + d4 * py_d;

% Substituting the placeholder state variables in the expressions for Kinetic Energy, Potential Energy and Power
K = subs(K,[theta1(t), theta1_d(t), theta2(t), theta2_d(t), posx(t), posx_d(t), posy(t), posy_d(t)],[q1, q1_d, q2, q2_d, px, px_d, py, py_d]);
P = subs(P,[theta1(t), theta1_d(t), theta2(t), theta2_d(t), posx(t), posx_d(t), posy(t), posy_d(t)],[q1, q1_d, q2, q2_d, px, px_d, py, py_d]);
Pow = subs(Pow,[theta1(t), theta1_d(t), theta2(t), theta2_d(t), posx(t), posx_d(t), posy(t), posy_d(t)],[q1, q1_d, q2, q2_d, px, px_d, py, py_d]);
Pow_d = subs(Pow_d,[theta1(t), theta1_d(t), theta2(t), theta2_d(t), posx(t), posx_d(t), posy(t), posy_d(t)],[q1, q1_d, q2, q2_d, px, px_d, py, py_d]);

% State derivative vector
dx = [q1_d; q2_d; px_d; py_d; q1_dd; q2_dd; px_dd; py_dd; Pow + Pow_d];

%% Create Matrices for Linearized System

A_mat = jacobian([q1_d; q2_d; px_d; py_d; q1_dd; q2_dd; px_dd; py_dd],[q1;q2;px;py;q1_d;q2_d;px_d;py_d]);
B_mat = jacobian([q1_d; q2_d; px_d; py_d; q1_dd; q2_dd; px_dd; py_dd],[tau1;tau2;Fx;Fy]);
H_mat = jacobian([q1_d; q2_d; px_d; py_d; q1_dd; q2_dd; px_dd; py_dd],[d1;d2;d3;d4]);

%% Create function for state evolution

x_vec = [q1;q2;px;py;q1_d;q2_d;px_d;py_d];
u_vec = [tau1;tau2;Fx;Fy];
d_vec = [d1;d2;d3;d4];

% Create function dx.m to use in ode
%matlabFunction(dx,"File","dx","Vars",{l1,lc1,l2,lc2,m1,m2,x_vec,u_vec,d_vec}); 
%clear dx; % Clear the variable dx to avoid conflict during simulation

% Create function KE.m for Kinetic Energy calculation
%matlabFunction(K,"File","KE","Vars",{l1,lc1,l2,lc2,m1,m2,x_vec});
%clear K; % Clear the variable K to avoid conflict during simulation

% Create function PE.m for Potential Energy calculation
%matlabFunction(P,"File","PE","Vars",{l1,lc1,l2,lc2,m1,m2,x_vec});
%clear P; % Clear the variable P to avoid conflict during simulation

% Create function A_matrix.m for A matrix of the linearized system
%matlabFunction(A_mat,"File","A_matrix","Vars",{l1,lc1,l2,lc2,m1,m2,x_vec,u_vec,d_vec});
%clear A_mat;

% Create function B_matrix.m for B matrix of the linearized system
%matlabFunction(B_mat,"File","B_matrix","Vars",{l1,lc1,l2,lc2,m1,m2,x_vec,u_vec,d_vec});
%clear B_mat;

% Create function H_matrix.m for H matrix of the linearized system
%matlabFunction(H_mat,"File","H_matrix","Vars",{l1,lc1,l2,lc2,m1,m2,x_vec,u_vec,d_vec});
%clear H_mat;

