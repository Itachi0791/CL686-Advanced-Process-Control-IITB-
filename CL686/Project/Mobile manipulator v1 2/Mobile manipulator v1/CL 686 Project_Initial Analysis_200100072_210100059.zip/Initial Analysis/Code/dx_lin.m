function dx_lin = dx_lin(x0,u0,d0,A,B,H,x,u,d)

    dx_lin = A*(x-x0) + B*(u - u0) + H*(d - d0);

end
