function Gamma = Gamma_matrix(A_matrix, B, T, n, m)
    if det(A_matrix) > 1e-10
        Gamma = (expm(A_matrix * T) - eye(n)) * pinv(A_matrix) * B;
    else
        ode_func = @(tau, x) reshape(expm(A_matrix * tau) * B, [], 1);
        [~, Y] = ode45(ode_func, [0, T], zeros(n * m, 1));
        Gamma = reshape(Y(end, :)', n, m);
    end
end