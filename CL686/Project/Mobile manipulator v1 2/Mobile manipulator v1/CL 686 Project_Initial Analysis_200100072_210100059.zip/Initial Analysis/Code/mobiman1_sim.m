%% Dynamical Simulation of Mobile Manipulator in MATLAB

% This is the main code than performs the dynamical simulation of the
% Mobile Manipulator system in MATLAB. In this code, link 1 refers to the
% mobile base and link 2 refers to the manipulator.

clear;
close all;

%% System Parameters

m1 = 5; % Mass of link 1
m2 = 1; % Mass of link 2
l1 = 1; % Length of link 1
l2 = 1; % Length of link 2
I1 = (m1*l1^2)/12; % Moment of inertia of link 1 about COM 
I2 = (m2*l2^2)/12; % Moment of inertia of link 2 about COM
lc1 = (l1/2); % Location of COM of link 1
lc2 = (l2/2); % Location of COM of link 2

dt = 0.001; % Time step
Tmax = 40; % Maximum time

tspan = 0:dt:Tmax; % Time duration for the simulation
Ns = (Tmax/dt)+1;

n = 8; % Number of state variables
m = 4; % Number of control inputs
p = 2; % Number of outputs

x0 =[0;0;0;0;0;0;0;0;0]; % Initial state

%% Actuator Inputs on the System

cond = 1; % Condition on which actuator input should be provided. Change this to get different results

if (cond==1)
    u = @(t,x)[1;0;0;0]; % Tau1 = Unit step input
elseif (cond == 2)
    u = @(t,x)[0;1;0;0]; % Tau2 = Unit step input
elseif (cond == 3)
    u = @(t,x)[0;0;1;0]; % Fx = Unit step input
elseif (cond == 4)
    u = @(t,x)[0;0;0;1]; % Fy = Unit step input
end

% For a particular case, the open-loop simulation of the nonlinear plant,
% continuous-time linearized plant, discrete-time lienarized plant and 

%% Disturbance Inputs on the System

% Damping coefficients
c1 = 5; 
c2 = 5;
cx = 5;
cy = 5;

d = @(t,x)[-c1*(x(5)); -c2*(x(6)); -cx*(x(7)); -cy*(x(8))]; 

%% Open-Loop Simulation of the Nonlinear Plant

options=odeset('abstol',1e-9,'reltol',1e-9);
[t,x] = ode45(@(t,x)dx(l1,lc1,l2,lc2,m1,m2,x,u(t,x),d(t,x)),tspan,x0,options); 

%% Open-Loop Simulation of the Continuous Time Linearized Plant

% Operating point for the continuous-time linearized model
x0_lin = zeros(n,1);
u0_lin = zeros(m,1);
d0_lin = zeros(m,1);

A0 = A_matrix(l1,lc1,l2,lc2,m1,m2,x0_lin,u0_lin,d0_lin);
B0 = B_matrix(l1,lc1,l2,lc2,m1,m2,x0_lin,u0_lin,d0_lin);
H0 = H_matrix(l1,lc1,l2,lc2,m1,m2,x0_lin,u0_lin,d0_lin);

[t_lin_cont,x_lin_cont] = ode45(@(t,x)dx_lin(x0_lin,u0_lin,d0_lin,A0,B0,H0,x,u(t,x),d(t,x)),tspan,x0_lin,options);

%% Open-Loop Simulation of the Discrete Time Linearized Plant

% Operating point for the discrete-time linearized model
x_lin_disc = zeros(length(t),n);
x_lin_disc(1,:) = x0_lin';

u_lin_disc = zeros(length(t),m);
d_lin_disc = zeros(length(t),m);

Phi0 = expm(A0*dt); % Phi matrix for the discrete-time model
Gamma0 = Gamma_matrix(A0,B0,dt,n,m); % Gamma matrix (for the control input) for the discrete-time model
Gamma0_d = Gamma_matrix(A0,H0,dt,n,m); % Gamma matrix (for the disturbance input) for the discrete-time model


for k=1:Ns-1

    u_lin_disc(k,:) = u(t_lin_cont(k),x_lin_disc(k,:));
    d_lin_disc(k,:) = d(t_lin_cont(k),x_lin_disc(k,:));

    xk = x_lin_disc(k,:)' - x0_lin;
    uk = u_lin_disc(k,:)' - u0_lin;
    dk = d_lin_disc(k,:)' - d0_lin;

    x_lin_disc(k+1,:) = (x0_lin + Phi0*xk + Gamma0*uk + Gamma0_d*dk)';
end

%% Calculation of different variables (acceleration, energy, torque)

% Vector storing the kinetic energy at different time instances
K = zeros(length(x),1); 
% Vector storing the potential energy at different time instances
P = zeros(length(x),1); 
% Vector storing the total energy at different time instances
T = zeros(length(x),1); 
% Vector storing the actuator work at different time instances
W_ac = zeros(length(x),1); 
% Vector storing rank of reachability matrix at different time instances
reach_vec = zeros(length(x),1);
% Vector storing rank of observability matrix at different time instances
obsv_vec = zeros(length(x),1);

for j=1:length(x)
    % Kinetic energy
    K(j,1) = KE(l1,lc1,l2,lc2,m1,m2,x(j,:)');
    % Potential energy
    P(j,1) = PE(l1,lc1,l2,lc2,m1,m2,x(j,:)');
    % Total Energy
    T(j,1) = K(j,1) + P(j,1);
    % Actuator Work
    W_ac(j,1) = x(j,end); 

    A_mat = A_matrix(l1,lc1,l2,lc2,m1,m2,x(j,:)',u(t(j),x(j,:)'),d(t(j),x(j,:)'));
    B_mat = B_matrix(l1,lc1,l2,lc2,m1,m2,x(j,:)',u(t(j),x(j,:)'),d(t(j),x(j,:)'));
    C_mat = C_matrix(l1,l2,x(j,:)');

    reach_vec(j) = rank(ctrb(A_mat,B_mat));
    obsv_vec(j) = rank(ctrb(A_mat,B_mat));


end

%% Animation

set(gcf,'Position',[500,500,1000,1000],'defaultAxesTickLabelInterpreter','latex'); 

delta = 0.35;

for i=1:100:length(t)
    x1 = x(i,3) + l1*cos(x(i,1));
    y1 = x(i,4) + l1*sin(x(i,1));
    x2 = x1 + l2*cos(x(i,1)+x(i,2));
    y2 = y1 + l2*sin(x(i,1)+x(i,2));

   
    plot([x(i,3),x1],[x(i,4),y1],'r','LineWidth',20)
    hold on
    plot([x1,x2],[y1,y2],'b-o','LineWidth',5)

    grid on, set(gca, 'FontSize',15)
    axis([-10,10,-10,10])
    xlabel('$x$','Interpreter','latex')
    ylabel('$y$','Interpreter','latex')
    title('Animation','Interpreter','latex')
    time = Tmax*(i-1)/(length(t)-1);
    subtitle("Time = " + time + " sec",'Interpreter','latex')
    hold off

    pause(0.01)

end

%% Plots showing the temporal variation of State

f1 = figure;

set(gcf,'Position',[1000,1000,1200,1200],'defaultAxesTickLabelInterpreter','latex'); 

subplot(4,2,1)
plot(t,x(:,1),"LineWidth",1.5,"Color","Blue")
hold on
plot(t_lin_cont,x_lin_cont(:,1),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,1),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$\theta_1$ [rad]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')


subplot(4,2,2)
plot(t,x(:,2),"LineWidth",1.5,"Color","Blue")
hold on
plot(t_lin_cont,x_lin_cont(:,2),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,2),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$\theta_2$ [rad]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(4,2,3)
plot(t,x(:,3),"LineWidth",1.5,"Color","Blue")
hold on
plot(t_lin_cont,x_lin_cont(:,3),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,3),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$p_x$ [m]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(4,2,4)
plot(t,x(:,4),"LineWidth",1.5,"Color","Blue")
hold on
plot(t_lin_cont,x_lin_cont(:,4),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,4),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$p_y$ [m]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

u_vec = u(t(1),x(1,:));

subplot(4,2,5)
plot(t,x(:,5),"LineWidth",1.5,"Color","Blue")
hold on
plot(t,(u_vec(1)/c1) * ones(length(t),1),"LineWidth",2,"Color","Magenta","LineStyle",":")
hold on
plot(t_lin_cont,x_lin_cont(:,5),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,5),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$\dot{\theta}_1$ [rad/s]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Equilibrium Value","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(4,2,6)
plot(t,x(:,6),"LineWidth",1.5,"Color","Blue")
hold on
plot(t,(u_vec(2)/c2) * ones(length(t),1),"LineWidth",2,"Color","Magenta","LineStyle",":")
hold on
plot(t_lin_cont,x_lin_cont(:,6),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,6),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$\dot{\theta}_2$ [rad/s]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Equilibrium Value","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(4,2,7)
plot(t,x(:,7),"LineWidth",1.5,"Color","Blue")
hold on
plot(t,(u_vec(3)/cx) * ones(length(t),1),"LineWidth",2,"Color","Magenta","LineStyle",":")
hold on
plot(t_lin_cont,x_lin_cont(:,7),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,7),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$\dot{p}_x$ [m/s]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Equilibrium Value","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(4,2,8)
plot(t,x(:,8),"LineWidth",1.5,"Color","Blue")
hold on
plot(t,(u_vec(4)/cy) * ones(length(t),1),"LineWidth",2,"Color","Magenta","LineStyle",":")
hold on
plot(t_lin_cont,x_lin_cont(:,8),"LineWidth",1.5,"Color","Red")
hold on
plot(t_lin_cont,x_lin_disc(:,8),"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$\dot{p}_y$ [m/s]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Equilibrium Value","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

%exportgraphics(f1,"Plot_linear_" + string(cond) + ".pdf")

%% Plots for Outputs

f2 = figure;

pe_x_arr = x(:,3) + l1 * cos(x(:,1)) + l2 * cos(x(:,1)+x(:,2));
pe_y_arr = x(:,4) + l1 * sin(x(:,1)) + l2 * sin(x(:,1)+x(:,2));

pe_lin_cont_arr = zeros(length(t_lin_cont),p);
pe_lin_disc_arr = zeros(length(t_lin_cont),p);

for i=1:length(t_lin_cont)
    pe_lin_cont_arr(i,:) = [(l1 + l2),0] + (C_matrix(l1,l2,x0_lin)*(x_lin_cont(i,:)' - x0_lin))';
    pe_lin_disc_arr(i,:) = [(l1 + l2),0] + (C_matrix(l1,l2,x0_lin)*(x_lin_disc(i,:)' - x0_lin))';
end
pe_x_lin_cont_arr = pe_lin_cont_arr(:,1);
pe_y_lin_cont_arr = pe_lin_cont_arr(:,2);

pe_x_lin_disc_arr = pe_lin_disc_arr(:,1);
pe_y_lin_disc_arr = pe_lin_disc_arr(:,2);

subplot(2,1,1)
plot(t,pe_x_arr,"LineWidth",1.5,"Color","Blue")
hold on
plot(t,pe_x_lin_cont_arr,"LineWidth",1.5,"Color","Red")
hold on
plot(t,pe_x_lin_disc_arr,"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$p_{e_x}$ [m]","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex","location","northeast")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(2,1,2)
plot(t,pe_y_arr,"LineWidth",1.5,"Color","Blue")
hold on
plot(t,pe_y_lin_cont_arr,"LineWidth",1.5,"Color","Red")
hold on
plot(t,pe_y_lin_disc_arr,"LineWidth",1.5,"Color","Green","LineStyle","--")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("$p_{e_y}$ [m","FontSize",15,"Interpreter","latex")
legend("Nonlinear Plant","Continous Linear","Discrete Linear","FontSize",15,"Interpreter","latex","location","best")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

%exportgraphics(f2,"Plot_outputs_comparison" + string(cond) + ".pdf")

%% Plots for Reachability and Observability

f3 = figure;

subplot(2,1,1)
plot(t,reach_vec,"LineWidth",1.5,"Color","Blue")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("rank($W_c$)","FontSize",15,"Interpreter","latex")
title("rank($W_c$) vs $t$","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

subplot(2,1,2)
plot(t,obsv_vec,"LineWidth",1.5,"Color","Blue")
xlabel("$t$ [s]","FontSize",15,"Interpreter","latex")
ylabel("rank($W_o$)","FontSize",15,"Interpreter","latex")
title("rank($W_o$) vs $t$","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')

%exportgraphics(f3,"Plot_reach_obs.pdf")

%% Energy Check

set(gcf,'Position',[500,500,800,800],'defaultAxesTickLabelInterpreter','latex'); 

figure;
plot(t, T - W_ac - T(1,1),"LineWidth",1.5,"Color","Blue") % Kinetic energy vs time
xlabel("$t$[s]","FontSize",15,"Interpreter","latex")
ylabel("Energy Difference [J]","FontSize",15,"Interpreter","latex")
title("Energy Check","FontSize",15,"Interpreter","latex")
set(gca,'FontSize',15,'TickLabelInterpreter','latex')
